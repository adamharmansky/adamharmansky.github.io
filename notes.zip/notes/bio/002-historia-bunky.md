# Úvod

> **CYTOLÓGIA** (cytos - bunka)

**Bunka** - základná stavebná, štruktúrna a funkčná jednotka všetkých
organizmov\footnote{okrem vírusov}

Je to základný prvok organizácie živej hmoty, hranica medzi živou a neživou
prírodou.

Sledujeme ich mikroskopom. Prvý mikroskop zostavil *Anthony Van Leeuwenhoek* a
__objavil__ bunku. *Robert Hooke* potom sledoval dutiny v korku, kde zaviedol
pojem **cellula** - *Bunka*. *Jadro* bunky potom sledoval **Robert Brown** a
**P. F. Gorianinov** potom začal tvrdiť, že všetky organizmy majú bunkovú
štruktúru. **Robert Wirchow** potom povedal, že bunky vedia vznikať **iba z
buniek**. 

> *"Omnis cellula e cellula"*

## Mikroskop

 - optický
   - 1200x
 - elektrónový
   - $10^6$x

## Bunková teória

 - J.E. Purkyně
 - M.J. Schleider
 - T. Schwaum

> 1838 - '39

1. Základom každého organizmu je **bunka**, ktorá je nostiteľom všetkých životných funkcií.
2. Každá bunka vzniká len z už existujúcej materskej bunky **delením**.
