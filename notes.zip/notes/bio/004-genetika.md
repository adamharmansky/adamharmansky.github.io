\title{Genetika}
\maketitle
\pagebreak

Genetika je samostatný vedný odbor biológie, ktorý sa zaoberá dedičnosťou a
premenlivosťou živých organizmov. Zakladateľom genetiky je **Johan Gregor
Mendel** - bol to brnenský mních a veľkú časť svojho života trávil tým, že
krížil rôzne organizmy. Robil experimenty hlavne s hrachom, no aj s včelami a
podobne. U hrachu sledoval dedičnosť viacerých znakov: napríklad tvar semien,
farbu semien, farbu kvetov, výšku rastliny a pod. Postupne sformoval isté
*Mendelove Zákony Kríženia*. Ešte nepoznal pojem *gén*, ale hovoril o
*dedičných vlohoch*.

**Dedičnosť** je vlastnosť živých organizmov, ktorá umožňuje výskyt totožných
alebo podobných znakov u potomstva pri pohlavnom rozmnožovaní.

**Premenlivosť**, alebo inak *varibilita* je vlastnosť živých organizmov, ktorá
umožňuje výskyt aj odlišných znakov potomstva. Umožňuje ju jednak vznik
mutácií, crossing over, kombinácie chromozómov pri oplodnení, ale aj
prostredie. Môže byť *dedičná* a *nededičná*. Dedičná je premenlivosť získaná
gémni a nededičná sa zakladá na podmienkach.

Genetická informácia každého organizmu je zapísaná v nukleových kyselinách,
resp. v *jadre*, či *nukleoide*. Zhruba v roku 1896 nukleové kyseliny objavil a
izoloval *F. Miescher*. Štruktúru DNA potom objasnili *J. Watson* a *F. Criek*
spolu s *R. Franklinovou*. 24.4.1953 vydali malý článok o štruktúre DNA a v
1962 dostali Watson, Criek a Wilkins Nobelovu cenu.

Základná stavebná jednotka sa nazýva **NUKLEOTID**. Poradie nukleotidov sa
nazýva v nukleovej kyseline sa nazýva **sekvencia**. Nukleotidy sa označujú
písmenami dusíkatej bázy v nukleotide.

**GÉN** je úsek molekuly DNA, ktorý nesie genetickú informáciu pre vytvorenie
určitej črty organizmu. Gén je základná funkčná jednotka dedičnosti.
Umiestnenie génu na molekule DNA sa nazýva *Lokus*. Konkrétna forma génu sa
nazýva **ALELA**.

Eukaryotická diploidná bunka nesie dva páry homologických chromozómov. *Každý
gén v eukaryotickej diploidnej bunke je zastúpený jedným* **alelickým párom**.

`A` - dominantná alela
`a` - recesívna alela

`Aa` - dominantný homozygot - prejaví sa dom. alela
`Aa` - heterozygot - prejaví sa dom. alela
`aa` - recesívny homozygot - prejaví sa recesívna alela

Súbor všetkých génov v bunke je **GENOTYP**. Ak zarátame aj dočasné regulačné
gény, volá sa to **GENÓM**.

Vonkajší prejav génu nazývame **ZNAK**. Súbor všetkých znakov nazývame
**FENOTYP**.

Poznám znaky *kvalitatívne* a *kvantitatívne*. **Kvalitatívne** znaky
podmieňuje buď jeden gén (monogénne), alebo malý počet génov silného účinku a
teda vplyv prostredia je minimálny. **Kvantitatívne** znaky sú podmienené
veľkým počtom génov malého účinku.
