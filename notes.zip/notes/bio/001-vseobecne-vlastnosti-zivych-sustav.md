\title{Všeobecné vlastnosti živých sústav}
\maketitle
\tableofcontents
\pagebreak

PRÍRODA:
	- živá
	- neživá

> pre živú a neživú prírodu platia rovnaké zákony, rozdiel medzi živou a neživou prírodou je život

*Život* - osobitná, kvalitatívne vyššia organizácia hmoty

Hranica medzi živou a neživou prírodu je *bunka*.

Živá sústava = organizmus - jednotka zivej prirody, ktora je schopna plnit vsetky svoje zivotne funkcie
Súbor organizmov toho istého druhu je populácia

# Chemické zloženie

organické | anorganické
 ---      | ---
kyslík    | **uhlík**
kremík    | vodík
hliník    | kyslík
železo    | dusík
vápnik    | síra
...       | fosfor

pre živé organizmy sú typické **makromolekulové látky** - *sacharidy, lipydy, bielkoviny, nukleové kyseliny*

# štruktúra

## neživá príroda

viacmenej homogénne látky

## živá príroda

zložitá hierarchická štruktúra; atómy tvoria makromolekuly, makromolekuly
tvoria organely, organely bunky, bunky tkanivá, tkanivá orgány, orgány
organizmus

**tkanivo / pletivo** - súbor buniek rovnakého pôvodu, tvaru a funkcie

**orgán** - súbor tkanív / pletív spolupracujúcich na jednej funkcii

# tok látok, energii a informácií

## tok informácií

v užšom zmysle - tok genetickej informácie pri rozmnožovaní
v širšom zmysle - akákoľvek komunikácia

## tok látok a energií

**metabolizmus** - súbor všetkých procesov, ktoré sa dejú v organizme

rozlišujeme ho na:

 - látkový
 - energetický

Ide stále o nejaký príjem, premenu a výdaj látok, či energií. z tohto hľadiska je metabolizmus otvorený systém

# regulácia

Chemické reakcie v organizme regulujú katalytické bielkoviny menom *enzýmy* a u vyšších živočíchov aj *hormóny*.

Všetky reakcie v organizme vedú do udržania stálosti vnútorného prostredia - **HOMEOSTÁZA**

# reprodukcia

Organizmy majú geneticky danú snahu a schopnosť rozmnožovať sa - kvôli udržaniu druhu / rodu.

Pre zachovanie druhu, resp. pre podobnosť dcérskych orgánov na tie rodičovské je potrebná **dedičnosť**. Súčasť dedičnosti je aj tzv, **premenlivosť** - čiže dcérsky organizmus je aspoň trochu odlišný. Vďaka premenlivosti sa dokážu organizmy prispôsobiť na výkyv prostredia.

# Úrovne organizácie živých sústav

## Nebunkové organizmy - Vírusy

Sú to veľmi jednoduché organizmy, zložené len z nukleovej kyseliny v bielkovinovom obale - *Nukleoproteínové častice*. Nemajú štruktúru bunky. Rozmnožovať sa dokážu iba pomocou hostiteľa.

## Jednobunkové organizmy

Ich telo tvorí jedna bunka, ktorá je schopná vykonávať všetky telesné funkcie, vrátane rozmnožovania.

 - prokaryotické - nemajú pravé jadro a iné membránové organely
   - baktérie
   - sinice
   - archeóny

 - eukaryotické - z nich vznikli mnohobunkové organizmy
   - prvoky
   - jednobunkové riasy
   - jednobunkové huby

## Bunkové kolónie

Bunkové kolónie môžu vznikať aj z prokaryotických aj eukaryotických buniek. Vznikajú keď sa bunky po rozdelení neodsťahujú preč. Bunky môžu byť (ale väčšinou nie sú) funkčne špecializované.

## Mnohobunkové organizmy

Vyvinuli sa z eukaryotických buniek. Aby sa tak stalo, museli medzi bunkami nastať tieto rozdiely:

 - tvarová diferenciácia
 - funkčná špecializácia

Bunky rovnakého tvaru, pôvodu a funkcie sa združujú do tkanív / pletív.
Z pletív vznikajú orgány - orgán - súbor tkanív/pletív, ktoré spolupracujú na určitej funkcii.

## Indivíduá vyššieho rádu

Diferenciácia vzniká medzi jedincami.
