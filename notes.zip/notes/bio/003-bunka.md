\title{Bunka}
\date{\today}
\maketitle
\tableofcontents
\pagebreak

# Štruktúra bunky

Štruktúra bunky je podmienená dedične a funkciou a typom bunky. Bunky podľa
štruktúry delíme na:

 - prokaryotické - **ZOPAKOVAŤ Z 1. ROČNÍKA**
   - 1 - 10 µm
 - eukaryotické
   - 10 - 100 µm

Tvar buniek môže byť guľovitý, vajcovitý, vretenovitý, hviezdicovitý,
kockovitý, polyhédrický, diskovitý, tyčinkovitý, ... Rastlinné bunky majú tvar
pevný, no živočíšne bunky sa tvarom vedia prispôsobiť prostrediu.

# Chemické zloženie bunky

60 - 90 % bunky sa skladá z vody a iných anorganických látok. Organické látky v
bunke sú zväčša **sacharidy, tuky, bielkoviny a nukleové kyseliny**.

## Funkcie zlúčenín v bunke

 - stavebná / konštrukčná
 - metabolická
 - zásobná
 - substrátová

## Anorganické látky v bunke

### Voda

Voda má v bunke jednu z najdôležitejších úloh. Bez vody by život nemohol
existovať v takej podobe ako ho dnes poznáme. Voda má v bunke **substrátovú
funkciu**, takisto je často **reaktantom a produktom** v mnohých chemických
reakciách. Bez vody by takisto nebol možný **transport** látok. Mnohé organické
látky závisia na prezencii vody pre správnu funkciu.

### minerálne látky

Minerálne látky ovplyvňujú **osmózu** a **metabolizmus**. Ióny týchto látok vo
vode podmieňujú **vodivosť**, využívanú napríklad aj v nervoch. Niekedy sa
stáva, že majú aj **stavebnú funkciu**. Najčastejšie ide o sodné, draselné,
vápenaté, horečnaté, či hydrogénuhličitanové anióny.

## Organické látky v bunke

### Bielkoviny

Bielkoviny sú **biopolyméry** - *makromolekuly* - ako iné polyméry sa skladajú
z **monomérov**, v tomto prípade **aminokyselín**. Existuje 21 aminokyselín.

```
      R - CH - COOH - karboxylová
          |              skupina
         NH2
            \
            aminoskupina
```


Aminokyseliny v bielkovinách sa spájajú **peptidovou väzbou**.

Podľa tvaru môžu byť bielkoviny guľovité - globulárne alebo vláknité - fibrilárne.

#### funkcie bielkovín

 - stavebná
   - napr. keratín, kolagén, elastín
 - v svaloch
   - aktín, myozín
 - katalytická
   - enzýmy
   - urýchľujú metabolizmus
 - transportná
 - regulačná
   - hormóny
 - informačná
 - zdroj energie
   - ale nie vždy
 - sú aj súčasťou cytoplazmatickej membrány

### Sacharidy

Sacharidy sa skladajú z uhlíka, vodíka a kyslíka. Niekedy sa im hovorí aj *uhľohydráty*, či *karbohydráty*, pretože na istý počet uhlíkov pripadá istý počet atómov z molekuly vody: $XC + XH_2O$.

Podľa štruktúry rozlišujeme monosacharidy, disacharidy/oligosacharidy, polysacharidy.

 - CUKRY - iba tie sladké
 - SACHARIDY - aj polysacharidy

#### Monosacharidy

 - 6 uhlíkové - *HEXÓZY* - $C_6H_{12}O_6$
   - glukóza
     - hroznový cukor
   - fruktóza
     - ovocný cukor
   - galaktóza
     - mozgový cukor

 - 5 uhlíkov - *PENTÓZY*
   - ribóza
   - deoxyribóza

#### Disacharidy

Disacharidy sú tvorené dvoma monosacharidmi spojenými väzbou.

```
SAcharóza
LAktóza
MAltóza
 - SALAMA
```

 - sacharóza
   - repný cukor
   - trstinový cukor
 - laktóza
   - mliečny cukor
 - maltóza

#### Polysacharidy

podľa funkcie ich delíme na:

 - zásobné
   - škrob (RASTLINY)
   - glykogén (HUBY, ŽIV)
 - stavebné
   - celulóza (RASTLINY)
   - chitín (HUBY, ŽIV)

#### Funkcie sacharidov

 - energetická
 - stavebná
 - zásobná

### Tuky

Presnejší pojem je **LIPIDY**. Sú to *estéry vyšších mastných kyselín a
trojsýtneho glycerolu*.

#### Funkcie tukov

 - zdroje energie
 - tepelnoizolačná funkcia
 - zásoba energie
 - stavebná funkcia
   - skladá sa z nich cytoplazmatická membrána
 - rozpúšťajú vitamíny a hormóny
   - D, E, K, A
 - pomáhajú prenášať nervové vzruchy

### Nukleové kyseliny

Nukleové kyseliny sú __biomakromolekulové látky__. Ich monomérmi sú **NUKLEOTIDY**. Funkciou nukleových kyselín je **ukladanie genetických informácií** a niekedy aj tvorba bielkovín (RRNA).

### DNA

DNA je skratka pre deoxyribonukleovú kyselinu.

 - nukleotid `DEOXYRIBONUKLEOTID`
   - 5C cukor = *deoxyribóza* - cukrová zložka
   - zvyšok $H_3PO_4$ - kyslá zložka
   - dusíkatá báza - zásaditá zložka
     - `ADENÍN - A`
     - `GUANÍN - G`
     - `CYTOZÍN- C`
     - `TYMÍN  - T`

![](027c.png)

Má tvar pravotočivej dvojzávitnice, ktorá sa skladá z dvoch *polynukleotidových
reťazcov*.

Dusíkaté bázy susedných reťazcov medzi sebou tvoria na základe princípu
**komplementarity** vodíkové väzby. Adenín sa viaže dvojitou vodíkovou väzbou
na Tymín a Guanín sa na Cytozín viaže trojitou vodíkovou väzbou.

### RNA

 - Štruktúrna jednotka `RIBONUKLEOTID`.
 - cukorná zložka - 5C cukor **ribóza**
 - zvyšok $H_3PO_4$ - kyslá zložka
 - dusíkaté bázy
   - `ADENÍN - A`
   - `GUANÍN - G`
   - `CYTOZÍN- C`
   - `URACIL - U`

RNA je pravotočivá **jednozávitnica** - iba jeden polynukleotidový reťazec.

Existujú **3 funkčné typy** RNA:

1. ribozómová RNA - rRNA
   - jednou zo zložiek ribozómov, na ktorých prebieha tvorba bielkovín
2. transferová RNA - tRNA
   - prináša aminokyseliny na ribozómy
3. mediátorová RNA - mRNA
   - slúži ako vzor pre tvorbu bielkovín
   - vzniká na základe DNA prepisom (transkripciou)

### Porovnanie RNA a DNA

vlastnosť     | DNA                                      | RNA
--------------|------------------------------------------|--------------------------
štruktúra     | pravotočivá dvojzávitnica                | pravotočivá jednozávitnica
sacharid      | deoxyribóza                              | ribóza
dusíkaté bázy | A G C T                                  | A G C U
funkcia       | uchovanie genetickej informácie          | prenos genetickej informácie
počet typov   | 1                                        | 3
výskyt        | jadro bunky, mitochondrie a chloroplasty | ribozómy, cytoplazma

# Štruktúra eukaryotickej bunky

Skladá sa z **organelov**.

 1. bunkové povrchy
 2. cytoplazma
 3. organely
   - membránové
   - vláknité
 4. inklúzie

## Bunkové povrchy

 - ochranná, krycia funkcia
 - prechod látok

### Cytoplazmatická membrána

Cytoplazmatická membrána sa nachádza na každej bunke. Je to základný bunkový povrch.

 - synonymum *plazmaléma*
 - polopriepustná - *semipermeabilná* / selektívne priepustná
   - kanály a *receptory* na povrchu
     - tok látok **aj** *informácií*

Skladá sa z dvojvrstvy fosfolipidov. V nich sa môžu nachádzať bielkoviny - ak
prechádzajú cez celú membránu, sú to **integrálne** bielkoviny. Ak prechádzajú
iba cez jednu vrstvu fosfolipidov, sú to **periférne** bielkoviny.

![](d894.png)

![](ffa6.png)

### Bunková stena

Bunková stena sa nachádza na povrchu rastlín, húb a prokaryotov. Má ochrannú a
mechanickú funkciu. Je pevná a jej tvar je stály. Je **plne permeabilná**.

## Cytoplazma

Cytoplazma je tekutý obsah bunky. Je to koloidný roztok rôznych organických aj
anorganických látok. Plní substrátovú funkciu.

## Bunkové organely

### Membránové organely

#### Jadro

Jadro je riadiace, koordinačné a reprodukčné centrum bunky. Je to mikroskopická
štruktúra (znie to malo ale je to najväčšia gulička v bunke). Skladá sa z:

![jadro](459c.png)

#### Plastidy

Plastidy sú organely typické pre rastlinné bunky - chromoplasty, chloroplasty, leukoplasty.

##### Chloroplast

V chloroplaste nastáva fotosyntéza.

 - sú semiautonómne
   - majú vlastnú DNA
   - dvojitá membrána
   - asi vznikli zo siníc čo sa vkradli do bunky
     - endosymbiotická teória


![chloroplast](5202.png)

##### Chromoplasty

Obsahujú xantofyly, karotenidy - sfarbujú kvety, plody, ...
Môžu to byť aj pomocné farbivá pri fotosyntéze.

##### Leukoplasty

leukos - biely - sú biele alebo bezfarebné

Majú zásobnú funkciu - ukladajú škrob alebo tuk:

 - amyloplasty - skladujú škrob
 - elaioplasty - skladujú tuk

#### Mitochondrie

Sú to respiračné a energetické centrá buniek

 - tiež sú semiautonómne
 - záhyby - kristy
 - výplň - matrix /matriks/

![mitochondria](bc18.png)

#### Endoplazmatické retikulum

Endoplazmatické retikulum tvorí niekoľko vrstiev membrán okolo jadra bunky. V
týchto vrstvách sa tvoria a zachytávajú ribozómy, v ktorých sa vyrábajú
bielkoviny. Má dve "formy" podľa množstva ribozómov:

 - hladká - málo ribozómov
   - tuky a vitamín D
 - drsná, zrnitá - veľa ribozómov
   - rôzne bielkoviny

![endoplazmatické retikulum](6d7a.png)

#### Golgiho aparát

Má hlavne **syntetickú** a **sekrečnú funkciu**:

 - syntetická funkcia
   - tvorba a úprava látok z endoplazmatického retikula
 - sekrečná funkcia
   - neustále sa z neho uvoľňujú **vezikuly** (mechúriky) s látkami
 - tvorba **lyzozómov** - tráviacich organel

![golgiho aparát](84fc.png)

\pagebreak

#### Vakuoly

 - u prvokov je veľa rôznych vakuol
 - takisto aj v rastlinách
   - v dospelých rastlinných bunkách vypĺňa vakuola skoro celú bunku - vtedy sa to volá **centrálna vakuola**
 - iba jedna membrána - **tonoplast**

##### funkcie

 - udržujú vnútorný tlak v bunke
   - **bunková šťava**
     - org. kyseliny, soli, inklúzie
 - zásobná funkcia
 - hydrolytické enzýmy
   - zabezpečujú rozklad látok pomocou vody

#### Lyzozómy

 - ako vakuoly, iba v živočíšnych bunkách
   - tiež hydrolitycké enzýmy
 - vznikajú z golgiho aparátu

### Fibrilárne organely

 - vždy zložené z bielkovín
   - bielkoviny, ktoré sa vedia sťahovať - kontraktilné bielkoviny
 - poznáme rôzne typy vlákien:
   - mikrotubuly - najhrubšie, duté
   - mikrofilamenty - tenké, plné
   - intermediárne filamenty - niečo medzi čo sa hrúbky týka, plné

#### Cytoskelet

 - dynamická bunková kostra
 - drží bunku pokope

 funkcia      | filament                                        | funkcia funkcie
--------------|-------------------------------------------------|---------------------------------------------------
 *mechanická* | intermediárne filamenty                         | stála poloha organel
 *pohybová*   | mikrofilamenty, no aj mikrotubuly(bičík, brvy)  | pohyb cytoplazmy, meňavkovitý pohyb, pohyb vezikúl
 *podporná*   | každý                                           | tvar buniek

#### Mitotický aparát

 - využíva sa počas mitózy
 - zabezpečuje, aby dcérske bunky mali rovnaké chromozómy
 - skladá sa z centriolov a deliacich vretienok z mikrotubulov

#### Chromozómy

 - sa niekedy zaraďujú ako fibrilárne organely

### Bunkové inklúzie

 - neživé súčasti bunky
 - buď sa vyskytujú v cytoplazme, alebo vo vakuole

 - buď sú to nestráviteľné látky pohltené z vonku, alebo sú to prebytočné odpadové produkty metabolizmu
   - často to sú kryštály soli - šťaveľan vápenatý
   - takisto kryštály bielkovín
   - alebo $SIO_2$

 - rôzne tvary
   - stiloidy
   - rafidy
   - drúzy

## Porovnanie

### rastlinnej a živočíšnej bunky

 vlastnosť           | živočíšna                    | rastlinná
---------------------|------------------------------|-----------
 tvar                | tvarovo variabilnejšia       | 
 povrchy             | len cytoplazmatická membrána | aj bunková stena
 špeciálne organely  | lyzozómy                     | plastidy, vakuoly

### Prokaryotickej a eukaryotickej bunky

Eukaryotické bunky sú väčšie, majú membránové organely. V prokaryotickej je
jedinou membránou cytoplazma. Jedinou membránovou organelou v prokaryotickej
bunke môžu byť *tylakoidy*. Jadro prokaryotickej bunky je iba *nukleoid*, v
prokaryotickej bunke sa môžu vyskytovať plazmidy. Prokaryotické bunky majú
stenu z *mureínu*.

# Príjem a výdaj látok v bunke

Môže sa diať:

 - bez spotreby energie - pasívny
 - za spotreby energie - aktívny

Energiu v bunke prenáša **ATP** - *adenozíntrifosfát* - má stavbu podobnú nukleotidu

 - adenín - ribóza - 3 krát zvyšok $H_3PO_4$
 - *Makroenergetické fosfátové väzby*

![ATP](f0cc.png)

## Pasívny transport látok

 - deje sa v membráne

### Difúzia

Prenikanie molekúl jednej látky medzi molekuly inej látky v smere
koncentračného spádu - z miesta s vyššou koncentráciou na miesto s nižšou
koncentráciou. Takto prechádzajú napríklad:

 - voda
 - oxid uhličitý
 - etanol
 - močovina
 - ...

Niekedy sa na tej difúzii zúčastňujú aj membránové bielkoviny. V tomto prípade
hovoríme o *uľahčenej difúzii*.

### Osmóza

Pasívny transport vody cez semipermeabilnú membránu kvôli vyrovnaniu
koncentrácií mimobunkového a vnútrobunkového prostredia. Z hľadiska osmózy sa
môže bunka nachádzať v troch osmotických prostrediach:

 - izotonické
   - vyrovnané
   - osmózan't
   - *fyziologický roztok* - NaCl 0.9%
 - hypertonické
   - viac mimo bunky ako v bunke
   - voda ide von z bunky
     - ako keď posolíme uhorky alebo slimáka
     - **plazmorýza** - zmrští sa bunka
     - **plazmolýza** - v rastlinných bunkách - bunka sa zmrští, ale bunková stena ostane v pôvodnom tvare, čiže vznikne prázdny pristor medzi bunkou a stenou
 - hypotonické
   - viac v bunke ako mimo
   - voda ide do bunky
     - deplazmolýza
     - pri živočíšnych bunkách môže bunka aj prasknúť - *plazmoptýza*
     - praskanie ovocia po dažďoch

## Aktívny transport látok

 - využíva energiu z ATP
 - ide proti smeru koncentračného spádu

### Špecifické transportné proteíny

 - integrálne bielkoviny v CP
   - buď duté
   - alebo menia štruktúru aby preložili látku na druhú stranu

patria sem:

 - iónové pumpy
 - sodnodraselné pumpy
 - prenášače - prenášajú väčšie veci - glukózu, aminokyseliny, ...

### Endocytózy

 - prenosy pri ktorých dochádza k prestavbe CM

#### Fagocytóza

 - príjem tuhých látok pomocou panôžok
 - treba to vôbec kresliť?! Áno treba ale nechce sa mi.

> Bunka panôžkami obklopí tuhú časticu, pohltí ju a vzniká **fagocytová
> vakuola**. Do vakuoly sa vložia hydrolitycké enzýmy a tuhá častica sa
> rozloží.

 - U nás sú toho schopné biele krvinky

#### Pinocytóza

 - príjem kvapalín vo forme kvapôčok
 - prebieha hlavne v tenkom čreve
 - takisto pinocytózou prebieha kvapôčková infekcia

![pinocytóza](eb4f.png)

### Exocytóza

 - von z bunky
 - vezikuly z golgiho aparátu

 - napríklad sa tak aj vylučujú hormóny

# Metabolizmus a prenos energie

 - metabolizmus je súbor všetkých procesov v bunke

Metabolické procesy sa delia na:

 - anabolické
   - z jednoduchších látok vznikajú zložitejšie
   - energia sa spotrebuje - **endergonické** ![](6d61.png)
   - redukčné deje
 - katabolické
   - zo zložitejších sa tvoria jednoduchšie
   - energia sa uvoľňuje - **exergonické**
   - oxidačné deje

Metabolické procesy sú vždy regulované **enzýmami** - biokatalyzátormi

 - enzým
   - apoenzým - bielkovinová časť
   - koenzým - nebielkovinová časť

Enzýmy sú špecifické katalyzátory. Majú dvojakú špecifickosť:

 - substrátová
   - katalyzuje rozklad len určitej látky
     - lipáza - lipidy
     - amyláza - škrob
   - za substr. špecifickosť je zodpovedný apoenzým
 - funkčná
   - katalyzuje len určitý typ reakcie
   - za to je zodpovedná nebielkovinová časť

Energia sa uvoľňuje do ATP

# Reprodukcia

Reprodukcia je vznik nových buniek z pôvodnej materskej bunky delením. Význam
reprodukcie je zachovanie druhu, zabezpečenie rastu a vývinu, základ
**ontogenézy** - vývinu jedinca od vzniku po zánik, regenerácia a vznik
pohlavných buniek.

## Bunkový cyklus 

**BUNKOVÝ CYKLUS** je život bunky od vzniku po zánik. Časové trvanie bunkového
cyklu sa nazýva **generačná doba**.

### G1 Fáza

 - hneď po delení
 - *hlavný kontrolný uzol* - regulačné mechanizmy sa starajú o bunku
 - ak podmienky nie sú dobré, bunka ide do G0 fázy
   - tam sú neuróny a červené krvinky

### S Fáza

 - výroba histónov, zdvojenie DNA, tvorba dvojchromatídových chromozómov

### G2 Fáza

 - bunka naďalej rastie, kontrolný uzol, chyby replikácie
 - tvorba tubulínu - z neho sa neskôr skladajú mikrotubuly deliaceho vretienka

### M Fáza

 - delenie

pri delení buniek najprv nastáva rozdelenie jadra - **karyokinéza**, potom
rozdelenie bunky - **cytokinéza**. Keď nastáva iba karyokinéza bez cytokinézy,
vznikajú viacjadrové bunky (napr. priečne pruhovaný sval).

## regulácia bunkového cyklu

1. stimulátory
   - urýchľujú delenie buniek
   - živiny, rastové hormóny - somatotropný hormón, cytokiníny, auxíny, ...
2. inhibítory
   - prinútia tie bunky zostať v G0 fáze
   - mitotické jedy, cytostatiká - taxín, modifikované dusíkaté bázy
   - používajú sa na liečbu nádorových a autoimunitných ochorení

Ak ku deleniu buniek dochádza v živom organizme, vtedy tomu hovoríme *in vivo*
a ak k nemu dochádza v laboratóriu, tak dochádza k deleniu *in vitro* - vieme
pestovať tkanivové kultúry.

## Chormozómy a ich stavba

Chromozómy sú fibrilárne organely tvorené DNA a histónmi. Najviac sú viditeľné
počas metafázy bunkového delenia. 

chromatída - jedno stočené klbko DNA

![dvojchromatídový chromozóm](f204.png)

primárna konstrikcia - chromatídy sú navzájom spojené. Centroméra je zároveň
miesto, kde sa pripájajú mikrotubuly deliaceho vretienka.

Jadierko vzniká zo satelitov chromozómov, ktoré ho majú.

Koncové časti chromozómov sa nazývajú teloméry - obsahujú DNA, ktorá sa na nič
nevyužije. Pri delení sa z nich kus odštiepi.

Počet, tvar a veľkosť chromozómov je typický pre každý druh organizmu.

Chromozómová sada - základný počet chromozómov v pohlavnej bunke. U človeka je
základný počet 23 chromzómov. Podľa počtu chromozómových sád sa bunky delia na:

1. haploidné - **n** - jenda chromozómová sada - pohlavné bunky - gaméty
2. diploidné - **2n** - dve chromozómové sady - prvá je zigota, všetky telové - somatické bunky sú potom diploidné

Splynutím gamét pri oplodnení vznikajú bunky s dvomi sadami.

V každej somatickej bunke existuje 1 pár nehomologických pohlavných chromozómov
- gonozómy. Ostatné sú homologické (22 párov) - sú rovnaké tvarom, veľkosťou a
obsahom.

## Delenie buniek

Delenie buniek môže prebiehať tromi spôsobmi - *mitózou* - nepriamym delením,
*amitózou* - priamym delením, *meiózou* - redukčným delením.

### Mitóza

Mitóza je delenie buniek, pri ktorom dcérske bunky po rozdelení sú totožné s
materskou bunkou - vznikajú kópie: $2n \to 2 \cdot 2n$. Replikácia DNA nastáva
v S fáze bunkového cyklu. Chromozómy sú *dvojchromatídové*, ale
**dešpiralizované** - zmotané vlákna DNA nemajú tvar chromozómov.

#### Profáza

Počas profázy sa DNA špiralizuje do chromozómov. V mikroskope vidíme klbko -
**SPIRÉM**. Jadrová membrána (karyoléma) sa počas profázy rozpadá. Jadierko
zaniká. Z tubulínu vznikajú mikrotubuly deliaceho vretienka - vzniká mitotický
aparát. Centrioly sa rozchádzajú na póly bunky.

![Profáza](1e56.png)

#### Metafáza

Počas metafázy sú chromozómy najlepšie viditeľné - usporiadajú sa do centrálnej
(ekvatoriálnej) roviny. Zhora vidíme hviezdicu - *monaster*.

![Metafáza](edc6.png)


#### Anafáza

Mikrotubuly deliaceho vretienka sa skracujú, dvojchromatídové chromozómy sa v
mieste centromér roztrhnú a už jednochromatídové chromozómy putujú k pólom
bunky. Pozorujeme dvojhviezdicu - *diaster*.

![Anafáza](27e4.png)


#### Telofáza

Chromozómy sa dešpiralizujú - okolo dešpiralizovaných chromozómov sa obnoví
karyoléma. Jadierko sa obnoví tiež. Vidíme *dispirém* - dve klbká. Prebieha
**karyokinéza**, rozdeľuje sa CM a nastáva **cytokinéza**.

![](ba9f.png)


### Meióza

Pri meióze nastáva delenie počtu chromozómov na polovicu. Pri meióze ide o dve
po sebe nasledujúce delenia - z nich prvé prebieha inak ako klasická mitóza -
nazýva sa **heterotypické** delenie. Druhé delenie sa nazýva **homeotypické**.
V každej diploidnej bunke sú dve kópie toho istého chromozómu.

#### Heterotypické delenie

Od klasickej mitózy sa odlišuje tým, že v profáze sa k sebe dvojchromatídové
chromzómy prikladajú a vznikajú "štvorchromatídové" chromozómy - **tetrády**.
Chromatídy toho istého chromozómu označujeme ako sesterské, chromatídy iného
chromozómu sú nesesterské. Nesesterské chromatídy homologických chromozómov sa
prekrížia (vznikajú **CHIAZMY**) a chromozómy si časti vymenia. Tento proces
rekombinácie genetickej informácie sa nazýva **Crossing Over**. Je to jeden zo
základných mechanizmov genetickej variability. Heterotypické delenie sa líši aj
v anafáze - chromozómy sa prichytia iba z jednej strany a neroztrhnú sa. Do
dcérskych buniek putujú celé dvojchromatídové chromozómy. Práve v tejto fáze
nastáva redukcia počtu chromozómov na polovicu - každá z dcérskych buniek má
teraz 13 dvojchromatídových chromozómov.

#### Homeotypické delenie

Homeotypické delenie nasleduje po krátkej interfáze v ktorej nenastáva
replikácia. Potom sa v anafáze dvojchromatídové chromozómy už trhajú na
polovicu a do dcérskych buniek prechádzajú ako jednochromatídové.

Výsledkom meiózy sú 4 haploidné bunky.


![meióza](82a5.png)

### Amitóza

Bunky sa po zdvojení genetického materiálnu rozdelia bez tvorby mitotického
aparátu. Deje sa všade, kde je potrebné rýchlo sa deliť - delenie baktérií,
prvokov, hojenie rán. Bunka sa natiahne, jadro sa zaškrtí, zaškrtí sa celá
bunka, organely sa rozdelia (ani nie rovnomerne) a sú dve bunky.

# Nadpis prosím

**zigota** - prvá diploidná bunka organizmu - je *totipotentná* - vie sa z nej
stať akákoľvek bunka. Sú aj *multipotentné*, ktoré sa vedia stať viacerými
druhmi buniek.

Diferenciácia buniek je rozdelenie na rôzne typy - v bunkách sa uplatní časť
genetickej informácie. Je regulovaná istými regulačnými procesmi.

Podstatou pohlavného a nepohlavného rozmnožovania je stále iba **delenie buniek**.
