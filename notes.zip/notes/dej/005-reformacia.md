\title{reformácia}
\maketitle

Dochádza k odsabeniu cirkvi - je nový *svetonázor* - gem je guľatá. Odohrával sa obchod s cikevnými sviatosťami a odpustkami. Cirkev má veľké majetky a moc a je skorumpovaná. Takisto nastváva *pápežská schizma* - sú až traja pápežovia. Proti cirkvi boli všetky vrstvy spoločnosti.

Ciele reformácie:

 - návrat k pôvodnému výklad písma svätého
 - návrat ku kristovej chudobe

31.10.1517 - martin liter pribil na kláštor v gutenbergu 95 téz

niektoré z téz:

 - zrušiť predaj odpustkov
 - návrat cirkvi k pôvodnej jednoduchosti a čistote
 - odňať cirkevným hodnostárom majetky
 - zaviesť prijímanie pod obidvoma spôsobmi
 - dovoliť kňazom ženiť sa
 - zrušiť ušnú spoveď a zjednodušiť cirkevné obrady
 - namiesto latinčiny zaviesť národnú reč ako bohoslužný jazyk
 - neuznávanie pápeža na hlavu cirkvi

čo sa potom stalo:

 - spor s pápežom levom 10. - exkomunikovali ho z cirkvi
 - aha luter nemal ráz židov

šírenie

 - švajčiarsko - kalvíni
 - francúzsko - hugenoti
 - anglicko - anglikáni

cirkev sa rozdelila na katolíkov a protestantov - začínali náboženské vojny. 

Reformácia vidla v **protireformácii a rekatolizácii**, ktorú viedol rím.

V švajčiarku a francúzku začali reformovať mešťania a vyššie vrstvy. Proti nim stála katolícka cirkev a panovník. V anglicku ale začal robiť reformáciu panovník.

# Náboženské vojny

## Nemecko

### Sedliacka Vojna

 - poddaní proti útlaku feudálov
 - zrušenie poddanstva

 - Tomáš Muntzer

 - poddaní boli porazení a prenasledovaní

### Šmalkadská vojna

 - reformácia nemeckých kinežat

 - protestanti vs karol V. a Ferdinand 1.

 - **Augsburgský mier** - zrovnoprávnenie náboženstiev, uznanie protestantov

## Francúzko - Hugenotské vojny

 - hugenoti = protestanti

 - nantský edikt - Henry IV. dal protestantom slobodu a náboženskú rovnosť

## Nizozemsko - vojna o nezávislosť

 - nizozemsko sa chcelo oddeliť od španielov
 - čoskoro sa pripojilo protikatolícke hnutie

## 30-ročná vojna

 - skoro celá európa proti hasburgovcom

 - česká vojna
 - falcká vojna
 - dánska vojna
 - švédska vojna
 - švédsko-francúzka vojna

 - vestfálsky mier

# Protireformácia

= rekatolizácia

 - katolíci chceli naspäť svojich veriacich

1. tridentský koncil - snem rímskokatolickej cirkvi - 18 rokov sa dohadovali
2. zoznam zakázaných kníh - 6000 zakázaných kníh
3. inkvizícia
4. jezuiti
