\title{Zámorské Objavy}
\maketitle

# Príčiny

## India

 - portugalci chceli korenie a iné hlúposti z indie
 - turci im zablokovali skoro celý balkán

## Rozvoj obchodu

 - chceli obchodovať
 - neni zlato
   - afrika

## Guľatá zem

 - chceli čo najkratšiu cestu do indie
 - kolombos chcel skúsiť ísť druhým smerom aby sa tam dostal
   - amerika

## Humanizmus a renesancia

 - poznanie ťa spraví dokonalým
 - objavovanie = poznanie

## Nové lode

 - boli lepšie lode ![](afd6.png)

\pagebreak

# Objavy

Ostatné krajiny robia vojnu čiže nemôžu, ale Portugalci a Španieli majú kľud.

 Portugalci                 | Španieli
----------------------------|-----------------------------
 začali 1415                | začali 1492 - skončila *rekonkvista* - zrušili arabov
 Henrich 1. "Moreplavec"    | Krištof kulumbus
 Obsadenie Ceuty            | 
 Oboplávanie afriky         | 

## Portugalci

 Henrich              | Bartolomeo diaz                           | Vasco de gama
----------------------|-------------------------------------------|----------------------
 ![Henrich](cb05.png) | ![bartolomeo diaz](5472.png)              | ![Vasco de Gama](36fc.png)
 financoval to        | južný cíp afriky - nedoplával až do indie | nešiel popri brehu, dostal sa až do indie - 1499

## Španieli

### Kolumbus

 - chcel dokázať že zem je guľatá a dostať sa druhým smerom do ïndie
 - stále si myslel, že sú v indii
 - **zmluva v tordesillas** - španieli a portugalci si rozdelili ameriku

### Amerigo Vespucci

 - prišiel skúmať rastliny
 - objavil že neni v indii

### Freñao de Magalhães

 - oboplával zem (teda vlastne zomrel 3 roky pred doplávaním do cieľa ale dajme tomu)

### Francis Drake

 - pirát

### James Cook

 - objavil austláriu

## Dôsledky

 - prísun drahých kovov
   - inflácia
 - nové štáty
 - trhová ekonomika
 - koloniálne veľmoci - spor
 - europanizmus
 - nové plodiny
 - úpadok cirkvi :)
 - šírenie chorôb
 - otrokárstvo
 - indiánin't
   - zničenie ríše inkov
   - zničenie ríše aztékov
