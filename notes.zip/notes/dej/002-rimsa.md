# Svätá rímska ríša

## Oto 1. Veľký

 - 955 - porážka Maďarov pri rieke Lech
 - 962 - pápežom korunovaný za cisára
 - základy svätej rímskej ríše

## Svätá rímska ríša nemeckého národa

 - skôr ideologický pojem ako štát
   - veľa kniežatstiev
   - cisár nemal až takú moc
 - cisár + pápež
   - cisár bol na korunovačnej jazde

### vzťah cisára a pápeža

 - najprv Ok
 - potom **Boj o investitúru**
   - dosadzovanie cirkevných hodnostárov do úradov
 - 1122 - **Wormský Konkordát**
   - pápež menuje biskupov
   - **ALE** kráľ tam musí byť a venuje im žezlo
 - ok vibavene.


### voľba cisára

 - 7 **kurfistov**
   - 3 duchovní
   - 4 svätskí
 - bolo to aj v zlatej bule

### panovníci

 - Friedrich 1. Barbarossa
   - križiacke výpravy
 - Karol IV.
   - zlatá bula - 1356
 - Habsburgovci
   - dedičnosť, korupcia

 1806 - ríša zaniká
