# Od Absolutizmu K Parlamentizmu

**Absolutizmus** = panovník vládne sám a neobmedzene

## Absolutizmus V Európe

1. Francúzsky - Ľudovít XIV.
2. Pruský - "Vojenský Kráľ" Friedrich Viliam 1.
3. Ruský - Peter 1. Veľký, Katarína 2.
4. Španielsko - Habsburgovci
5. Anglicko - Jakub 1, Karol 1.
6. Habsburgská monarchia - Mária Terézia, Jozef 2.
