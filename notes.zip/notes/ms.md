	Adam Harmanský, Ďurďošík 164, 04445 Bidovce Slowakei

	Siemens, Werner-von-Siemens-Straße 1 80333, München, Deutschland

\vspace{25pt}
\large

\begin{tabbing}
\hspace{3cm}\=\kill
Betreff/Bezug: \> \textbf{MOTIVATIONSSCHREIBEN}
\end{tabbing}


Sehr geehrter Herr Direktor,

ich möchte an der Position eines Programmierers von eingebetteten Systemen
ihres Unternehmens arbeiten, weil ich dieses Fach abwechslungsreich und
perspektiv finde.

Zu meinen Stärken gehören Kommunikativität, die Wille zu lernen, Geduld und
Kreativität. In der Vergangenheit habe ich mich bereits mit IT beschäftigt. Als
ich 16 war, habe ich bereits Low-Level Programmierung gemacht und meinen
eigenen 8-Bit Computer gebaut. Ich habe ein Praktikum bei T-Systems gemacht und
dort habe ich Webseiten geschrieben und dann Robotik gemacht, also kann ich
auch High-Level Programmieren. Diese Fähigkeiten kann ich in die Stelle als ein
Programmierer von eingebetteten Systemen einbringen. In der Stellenbeschreibung
zu der Stelle habe ich genau die Anforderungen gefunden, die ich suche. Die
stelle wird es mich Ermöglichen, meine Teamfähigkeit zu verbessern. Meine
Erfahrung mit Computer und Elektronik kann ich sehr gut in das Unternehmen
einbringen. Damit kann ich die Ziele dieses Unternehmens unterstützen. Ich bin
sicher, dass meine beruflichen und persönlichen Ziele sehr gut mit den Zielen
des Unternehmens übereinstimmen. Darüber hinaus, habe ich das Ziel, meine
Kenntnisse in Programmieren zu verbessern.

Ich freue mich über eine Einladung zum Bewerbungsgespräch.

Mit besten Empfehlungen,

\qquad Adam Harmanský

\begin{flushright}
Ďurďošík, Slowakei

\today
\end{flushright}
