# mapa

mapa - zmenšený, zjednodušený, skreslený, obraz zeme premietnutý do roviny

# glóbus

proces ako vzniká glúbus:

ZEM
 - GEOID - morská hladina na celom povrchu (žiadne hory)
 - ELIPSOID - odstránenie hruškatosti zeme
 - GUĽA - ostránenie elipsoidovosti zeme
 - GLÓBUS


mapa a glóbus nám umožnujú vidieť vzájomné vzťahy / súvislosti medzi objektami a javmi v priestore.

používame **geografickú sieť súradníc** - tovria ju rovnobežky a poludníky.

## poludník

 - čiara na povrchu zeme, ktorá spája severný a južný pól po povrchu zeme.

 - na každom mieste na poludníku je rovnaký miestny čas
 - každý poludník má 20004 km - všetky sú rovnako dlhé
 - nultý poludník nám rozdeľuje zem na dve pologule - jeho opakom je 180-ty poludník, ktorý je zároveň dátumovou hranicou

## rovnobežka

 - priesečník povrchu zeme s rovinu, ktorá je kolmá na zemskú os.

 - najdlhšia rovnobežka **rovník** - 40075km
 - severná a južná polguľa

geografická šírka - uhol medzi bodom a rovníkom
geografická dĺžka - uhol medzi bodom a nultým poludníkom

## mierka mapy

 - pomer zmenšenia mapy k zemi

**plány** - 1 : 500 - 1 : 5 000

 - zobrazujú konkrétne veci
 - nezobrazujú nadmorskú výšku
 - napr. katastrálny plán

**mapy veľkých mierok** - 1 : 10 000 - 1 : 200 000

 - malé územia, podrobné

**mapy stredných mierok** - 1 : 200 000 - 1: 1 000 000

 - najmenej používané

**mapy malých mierok** - 1 : 1 000 000 a viac

 - málo podrobné, veľké územie


## Obsah mapy

 - **generalizácia obsahu mapy** - zjednodušenie

 - všetko vyobrazené na samotnej mape
 - 3 dôležité časti obsahu mapy sú:
   - výškopis
     - nadmorské výšky/hĺbky
     - farebné značenie / vrstevnice
     - čiary, ktoré spáajú body s rovnkaou nadmorskou výškou sa označujú ako **IZOHYPSY**(nad morom) a **IZOBATY**(pod morom)
     - **izolínie** - čiary spajajuce body s rovnakou hodnotou javu
   - polohopis
     - súbor značiek, ktoré nám na mape ukzujú, kde konkrétne na mape sa nachádzajú nejaké objekty/javy
     - Všetko čo je v mape zaznačené musí byť zaznačené v **legende**
     - značky:
       - bodové
       - líniové
       - plošné
   - popis mapy
     - názvy, ktoré sa v mape nachádzajú
     - veci sa rozličujú aj na základe písma

### 4 druhy máp podľa obsahu

 - katastrálne mapy
 - topografické - najpresnejšie mapy, využívajú sa na merania, najmenší podiel skreslenia
 - všeobeňogeografické mapy - zobrazujú iba hlavné geografické informácie
 - tematické - na jednu tému - všeobeňé prvky sú potlačené
   - prírodné
   - spoločenské
   - často sa tam vyskytujú rôzne grafy a prílohy
     - kartogram
       - na mape pomocou farby ukazuje kvantitu javu na istom území
     - kartodiagram
       - vrámci jednotlivých celkov sa nachádza aj nejaký graf

## Vznik mapy

### Druhy zobrazenia

 - azimutálne zobrazenie
    - dotýka sa jedným bodom
 - valcové zobrazenie
    - dotýka sa rovníka
 - kužeľová projekcia
    - dotýka sa vedľajšej rovnobežky

na základe skreslenia:

 - rovnakouhlé
 - rovnakoplošné
 - rovnakodĺžkové

## GPS a GIS

**GPS** - globálny polohový systém

 - kozmický systém
   - dokopy 27 satelitov
 - riadiace stanice
   - zaznamenávajú svoju polohu satelitu
 - klient

**GIS** - geografický informačný systém

 - každá informácia o konkrétnom bode na zemi
