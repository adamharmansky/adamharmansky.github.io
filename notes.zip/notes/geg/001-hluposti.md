# História geografie

**ERATOSTENES** - vynašiel geografiu a sitko
 - dielo *Geografika*

**GEOGRAFIA** = GEOS(zem) + GRAFIS(opis) - opis zeme - *zemepis*

potom geografiu rozvíjali *Arabi*.

 - už sme všetko zmapovali čiže vpodstate je takáto geografia nanič

súčasná gografia sa zameriava na vysvetľovanie príčin rozmiestenia javov a prograsov v krajine. Zuajíma sa vzťahom medzi človekom a prírodou.

 - **ALEXANDER VON HUMBOLT** - nemecký geograf - zakladateľ modernej gegrafie.
 - **KARL RITTER**
 - **FRIEDRICH RATZEL**

## Kartografia

 - holandský kartograf - **MERCATOR** - vydal v 17. storočí **Atlas**
 - na slovensku bol populáry *Mikovíny* - kráľovský kartograf uhorska
   - mapové diela uhorských tolíc, ktoré publikoval aj matej Bel

# Geograficky vedný systém

GEOGRAFIA

 - FYZICKÁ GEOGRAFIA - prírodné zložky krajiny
 - HUMÁNNA GEOGRAFIA - obyvateľstvo a jeho aktivity v krajine


 - REGIONÁLNA GEOGRAFIA - prepája fyzickú a humánnu GEG
 - KARTOGRAFIA - tvorba máp
 - PLANETÁRNA GEOGRAFIA - ako iné objekty ovplyvňujú zem
 - Náuka o krajine a životnom prostredí

Objektom výskumu geografie je *Krajinná sféra*, ktorá je zložená g *Geosfér*:

 - prírodné - fyzická geosféra
   - hydrosféra  - HYDROGEOGRFIA
   - atmosféra   - METEOGEOGRAFIA
   - biosféra    - BIOGEOGRAFIA
   - pedosféra   - PEDOGEOGRAFIA
   - litosféra   - LITOGEOGRAFIA
 - hummánna / socioekonomická sféra - tvorená obyvateľstvom a jeho aktivitami a prejavmi v prostredí
   - geografia obyvateľstva, dopravy, cestovného ruchu
   - demografia

Predmetom výskumu sú procesy, javy a vzťahy v krajine.

Krajina - časť krajinnej sféry, ktorá **musí** obsahovať každú jedno geosféru.

Geografia vždy skúma **priestorové rozmiestnenie javov**, príčiny vzniku, dôsledky a prejavy v prostredí, pričom negeografické vedné disciplíny sa skôr zameriavajú na samotné javy a procesy.

hranica zemského plášťa - **MOHOROVIČIČOVA PLOCHA DISKONTINUITY**

 - tam sa lámu zemetrasné vlny!
 - 30-40 km pod zemou

vrchná hranica krajinnej sféry - **OZÓNOVÁ VRSTVA**
