prezentácie na témy PO TROJICIACH

 - extrémy počasia
 - pitná voda
 - sopečná činnosť
 - zemetrasenia
 - tsunami
 - erózia pôdy
 - negatívne vplyvy človeka na biosféru
 - povodne
 - globálne otepľovanie
 - horotvorná činnosť

> [atlas.mapy.cz](https://www.atlas.mapy.cz)
