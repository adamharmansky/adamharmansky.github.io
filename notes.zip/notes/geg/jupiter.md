# Jupiter

 - pata planéta
 - najväčšia planéta
   - plynný obor
 - tretí najjasnejší objekt na oblohe
 - volá sa po rímskom bohovi Jupiterovi

![Pujiter](8329.png)

 - 79 mesiacov
 - $1.8982 * 10^{27}$ kg
   - 2.5 g na "povrchu"
   - veľký gravitačný vplyv na slnečnú sústavu
   - keby bol o 80% ťažší, mohol by sa stať hviezdou
   - hmotnosť jupitera je asi 2.5-násobkom hmotnosti všetkých planét v slnečnej sústave dokopy

 - dĺžka dňa - 10 pozemských hodín
 - dĺžka roka - 12 pozemských rokov

 - zloženie
   - veľká guľa plynu
     - vodík
     - hélium
     - metán
     - amoniak

 - nemá presne definovaný penvý povrch
 - veľmi slabý prstenesc
 - silná magnetosféra

## Mesiace

 - Io
 - Europa
 - Ganymede
 - Callisto

![Yo Europa Ganymede Calisto](5ef7.png)

 + 70

## Prstence

 - slabý prstenec
 - 3 časti
   - vnútorný kruh častíc
   - hlavný prstenec
   - vonkajší pstenec

## Zloženie

 - pevné jadro
   - vo znútri jadra je teplota až 30000K
 - vodíková atmosféra
   - 1.3 MPa
   - 33 K
 - vrstva hélia
 - vraj tam pršia diamanty

 - **Veľká červená škvrna**
   - vír / búrka


![čeľká ververná kšvrna](2938.png)
