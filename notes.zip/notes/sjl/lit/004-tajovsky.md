# Jozef Gregor Tajovský

Jozef Gregor Tajovský sa volá podľa dedinky *Tajov*, kde vyrastal. Keďže
pochádzal z viacdetnej rodiny, vyrastal so starými rodičmi s ktorými mal dobrý
vzťah. Najprv pôsobil ako dedinský učiteľ v čase maďarizácie, aj keď s ňou
nesúhlasil. Preto potom radšej išiel na štúdium do prahy a neskôr pôsobil ako
bankový úradník a to nie len na území slovenska, ale aj medzi Slovákmi v
zahraničí. Pre jeho tvorbu je dôležitý aj *Nadlak* v Rumunsku. Do prvej
svetovej vojny sa aktívne zapojil, dostal sa do ruského zajatia, kde spolu s
Jesenským vstúpili do légií a bojovali za vytvorenie Československa. V roku
1919 sa vrátil na Slovensko kde naďalej pôsobil ako spisovateľ.

Bol majstrom krátkej prózy. Písal krátke črty a poviedky, ktoré sú tematicky
veľmi široké. Patria medzi ne spomienky na detstvo (dielo *Do školy*), na
starých rodičov (*Žliebky*, *Prvé hodinky*), sociálne otázky (napríklad *Mamka
pôstková*) a príbehy a portréty obyčajných ľudí (napríklad *Maco Mlieč*). Ľudia
v tejto tvorbe sú veľmi chudobní, ale na dušu bohatí. Vo všetkých kratších
prózach využíva *kritickorealistickú metódu* - jeho zámerom nie je len zachytiť
verne, ako to na dedine vyzerá, ale aj zachytiť negatívne stránky života, za
ktoré tí chudobní ľudia nemôžu.

Tajovský okrem prózy písal aj dramatické diela. Jeho najznámejšie diela sú
jednoaktovky *Matka*, *V službe*, *Hriech*, *Tma*, ale vytvoril aj klasické
viacdejstvové hry ako *Ženský zákon*, *Nový život*, či *Statky-zmätky*. Po roku
1918 napísal ďalšie drámy ako *Smrť Ďurka Langsfelda*, *Blúznivci*, či
*Hrdina*. Je zakladateľom novodobej slovenskej realistickej drámy. Bol jeden z
mála slovenských dramatikov - dovtedy sa v našich divadlách hrali najčastejšie
dramatizované literárne diela a prejavy z biblie. Očistil drámu od
dekoratívnosti a všeľudských právd a sústredil sa na zachytenie realistického
obrazu slovenskej dediny.

## Statky Zmätky

Najlepšie Tajovského dielo. Napísal ho ešte počas pobytu v Nadlaku. Žáner diela je *dráma* - divadelná hra s vážnym obsahom. Odohráva sa v štyroch dejstvách. Témou hry je uzatváranie manželstva, bez lásky, kvôli majetku. Zachytáva obdobie od Vianoc do ďalších Vianoc - sviatkov pokoja, rodiny a tradícií. Odohráva sa medzi tromi rodinami:

 Ľavkovci | Palčíkovci           | Kamenskí
----------|----------------------|----------
 Jano     | Ondrej               | Tomáš
 Žofa     | Mara - Žofina sestra | Kata - Ondrejova sestra
 syn Ďuro |                      | Zuza
          |                      | Eva + Mišo Kaňúrik
          |                      | Ondriš

Palčíkovci vymysleli, že Ďuro si vezme Zuzu a nasťahujú sa ku nim pod zámienkou, že potom po nich zdedia majetok. Ona potom otehotnela a ďuro mal problém. Rozišli sa a začal chodiť s nejakou Betou. Janovi sa páčila a Žofa ju tiež podporovala. Len Palčíkovcom sa nepáčila lebo nepomáhala v dome.

Pre Tajovského je typický hovorový jazyk s dialektizmami. Takisto používa *elipsu*.
