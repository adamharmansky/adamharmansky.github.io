# Symbol, Epiteton

## Symbol

Symbol je *dohovorený znak*. Pochádza z gréckeho *Symbollon* - dohovorený znak. My na literatúre ale hovoríme o symbole **leterárnom**

Symbol v literatúre je tretím hlavným druhov tópu popri metafore a metonymii. Vzniká tak, že k pôdovnému významu sa pridáva ďalší, ktorý je zatreterjší, menej zjavný k pôvodnému výnamu a tak slovo nadobúda aj **abstraktný zmysel**. Symboly sa stali halvným umelecký prostriedkom pre *sybolizmus*, ktorý v literatúre vznikol v poslednej tretine 19. storočia a vo výtvarnom umení na začiatku 20. storočia. U nás bol predstaviteľom symbolizmu **Ivan Krasko**.

	Hej topole, tie topole vysoké!
	Okolo nich šíre pole,
	čnejú k nebu veľké, čierne
	- zrovna jako česy bôle - 
	topole.

> Ivan Krasko, Topole

## Epiteton

Najjednoduchší a najčastejší umelecký prostriedok - *Básnický prívlastok*. Je vyjadrením poetickosti a lyrickosti. Býva vyjadrený akostným prídavným menom.

TRÁVA - zelená, dlhá  , suchá
SLNKO - jasné , žlté  , horúce
LÚKA - rozľahá, zelená, trojuholníková

poznáme dva druhy prívlastku

 - epiteton constans - prídavné meno sa viaže k podst. menu na toľko, že sa často vyskytujú spolu
 - epiteton ornans - ozdobný - originálny, poetický
