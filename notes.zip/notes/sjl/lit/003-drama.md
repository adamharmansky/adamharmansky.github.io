# Dráma

 - jeden z troch literárnych druhov (bližšie má k epike)
 - v divadle sa príbeh odohráava v *prítomnom čase*
 - keďže je to dru**H**, tak vrámci neho existujú rôzne žánre
 - pri realizácii divadelnej hry sa uplatňujú aj verbálne aj neverbálne prostriedky
   - hovorový a umelecký ![](5707.png)
     - repliky a dialógy
 
neverbálne prostriedky sú:

 - paralingvisticé
   - pohyb, tanec
 - extralingvistické
   - rekvizity, svetlo, šum, ...

Je to najkomplexnejší literárny druh

## Vznik drámy

 - vznikla v starovekom Grécku z náboženských osláv boha Dyonýza (vína a radosti)
   - na začiatku vystupoval protagonista a **chór** (12-15 členov)
     - chór na javisko vzostupoval slávnostným krokom
     - na čele *korylej* a za ním *choreuti*
     - spieval, tancoval, komentoval dej a charakterizoval vlastnosti a konanie postáv
   - polkruhový stupňovitý útvar v amfiteátri - orchestra
   - hrali iba plnoprávni muži
     - mali masky na paličke
 - v stredoveku
   - pouličné divadlo na igurici
     - nájomní herci pre šľachtu
 - v novoveku
   - najprv alžbetínske divadlo
   - 18. storočie - kamenné divadlo
 - najväčší rozvoj drámy bol v 20. storočí
   - divadlo, rozhlas, film, ...

## Vonkajšia kompozícia divadelnej hry

 - to čo vníma divák - scéna
   - herci, orchestra, kulisy, paralingvistické prostriedky
 - dejstvá, výstupy, scéna (obraz)
   - dejstvo - časť oddelená prestávkou
     - väčšinou 3 dejstvá
     - hra s jedným dejstvom - *jednotaktovka*
 - výstup - zmena počtu postáv
 - dialóg, monológ, replika - prehovor jednej postavy
   - natšia replika - citoslovce
   - najdlhšia replika - monológ

## Vnútorná kompozícia divadelnej hry

![](3a04.png)


## Renesančá dráma

Renesančá dráma je inšpirovaná antickou drámou.

### William Shakespeare

 - predstaviteľ anglickej humanistickej renesančnej drámy
 - vytvoril rozsiahle dielo, ktoré tvorí 37 divadelných hier a niekoľko básnickych prvkov z ktorých najpopulárnejší je cyklus 154 sonetov.
   - za vrchol jeho tvorby sa považujú tragédie
   - podkladom pre jeho písanie boli kroniky a udalosti z antického grécka
 - jeho tvorbou sa začínajú dejiny novodobej drámy
   - zaviedol kamenné divadlá
   - zohľadnil nároky divákov
   - zaslúžil sa o rozvoj dramatickej literatúry

#### Tvorba

##### Komédie

 - krotenie zlej ženy
 - sen noci svätojánskej
 - mnoho kriku pre nič
 - veselé panie z windsoru

##### Tragédie

 - romeo a júlia
 - hamlet
 - otello
 - mekbet
 - kráľ lír či čo

##### Historické hry

 - henry 6.
 - richard 3.

#### Hamlet

 - vznikol na základe dvoch zdrojov - kronika *História Dánska - Saxo Grammaticus* a neznáma a stratená hra Thomasa Kyda.
