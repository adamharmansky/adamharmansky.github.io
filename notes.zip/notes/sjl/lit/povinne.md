# Zoznam povinnej literatúry

mesiac | dielo
-------|--------
11     | shakespeare - hamlet
11     | tajovský - statky, zmätky
2      | ján kollár - všespiev zo slávy dcéry
3      | romain roland - peter a lucia
4      | sládkovič - marína
4      | krasko - výber
5      | palárik - zmerenie
5      | molier - lakomec
