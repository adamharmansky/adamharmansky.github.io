# Sonet

sonneto - jemný zvuk - jemná, citlivá báseň

spolu 14 veršov - vždy 14

rozstrofované na buď 4 4 3 3, alebo 4 4 6:

 - prvé štvorveršie je **téza** - myšlienka sonetu
 - druhé je **antitéza** - protirečí myšlienke
 - syntéza - zhrnutie
 - pointa

V slovenčine sa sonet nazýva aj **znelka**. 15 sonetov je **zenlkový veniec**.

Ako žáner vznikol v taliansku, využíva rozličné veršové systémy. Rozšíril sa do celého sveta - u nás napríklad sonetoval **Hviezdoslav**, **Vajanský**, či **Rázus** alebo **Válek** a **Kostra**, ktorí robili ironizujúce ironické sonety.

# Óda

ode - pieseň

Óda je **oslavná báseň**, ktorá ospevuje vejakého hrdinu, výnimočný skutok, alebo nejakú udalosť. Vyniká nadnesenosťou a pátosom (pokorou, úctou). Patrí ku reflexívnej lyrike a v antickej poézii označovala zborovú oslavnú pieseň. Väčšinou bola napísana v časomernom veršovom systéme. U nás ódu písal napríklad **Ján Holý**. Známe ódy sú **óda na radosť** a **óda na mladosť**.
