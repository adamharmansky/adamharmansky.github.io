> ten skutok sa nepodaril

# Okná

U pani profesorky Karoľovej mám už dlhší čas resty. Keď sme na informatike
preberali Microsoft Windows, ako pravý používateľ Linuxu som Windows nemal. Ale
okrem problémov s Microsoft produktmi sa mi na ceste k dobrému vzťahu s pani
profesorkou vyskytli aj iné prekážky. Jednou z nich boli aj domáce úlohy.

Miesto pravého programovania sme na hodinách informatiky totiž preberali iba
kreslenie pomocou páru príkazov z knižnice tk. Z tohoto "programovania" sme
dostávali domáce úlohy ako *nakresli auto*, či *nakresli rebrík*. Jedna domáca
úloha, mám pocit, že to dokonca bola finálna úloha z kreslenia, bola nakresliť
dom so vzormi ako na tradičných chatách v Čičmanoch. Keďže sme nepoznali žiadne
logické funkcie, mali tieto vzory byť podľa zadania iba pevne dané.

Domácu úlohu som robil spolu nemenovaným spolužiakom Jakubom Imrichom, lebo sme
sa v našich schopnostiach akurát dopĺňali: ja som to vedel a on nie. Ako sa
teda patrí, do úlohy sme sa pustili večer pred termínom. No ale samozrejme sme
sa potrebovali najprv rozohriať, čiže sme si ešte zahrali pár partií
počítačovej hry Overcooked. Pár partií sa ale pretiahlo do ôsmej hodiny večer.
Moja mama ma teda prišla zbuzerovať že mám vypínať počítač. V tom momente sme
si uvedomili, že sme ešte ani nezačali úlohu. Začali sme teda písať, no na naše
limitácie (musel som to Kubovi vysvetľovať) sme ani do deviatej hodiny
nestíhali. Mama nám to teda prerušila aj napriek tomu, že ja som svoju úlohu
ešte nedokončil. Dokončiť úlohu mi doslova zakázala. Ja som ale vedel, ako ma
má pani Karoľová rada a potreboval som spraviť nie len minimum, ale aj niečo
navyše do úlohy. Povedal som teda mame, že idem spať, ľahol som si do postele a
zapol počítač, no vypol obrazovku. Potom som sa na ňho na telefóne, ktorý som
mal skrytý pod perinou, pripojil pomocou SSH, nástroja na diaľkové prepojenie a
o desiatej večer som na tej malej obrazovke naprogramoval úžasný procedurálny
dom s náhodnými vzormi a farbami. So svojím dielom som bol veľmi spokojný.

Na hodine si pani profesorka prezerala naše diela. Bol som zvedavý, čo povie na
môj úžasný procedurálny dom plus plus 3000. Prvá veta, čo vyšla z jej úst ale
bola:

> Nemáš okná.

:(
