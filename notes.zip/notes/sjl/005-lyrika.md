# Časomerný veršový systém

Je založený na striedaní dlhých a krátkych slabík, resp. na dĺžke ich trvania. Krátka slabika je polovične dlhá ako dlhá slabika. V dlhej slabike je buď dĺžeň alebo spoluhláska. No v antickej literatúre sa za dlhú slabiku považuje slabika, ktorá:

 - obsahuje dlhú samohlásku
 - ak po krátkej samohláske následujú aspoň dve spoluhlásky
 - ak slabika spojí pred pauzou vyznačenou interpunkčným znamienkom

Dlhá slabika predstatovala ťažkú dobu a krátka označovala ľahkú dobu.

Základnou časovou jednotkou bola jedna móra. Krátka mala jendu móru a dlhá slabika dve móry.
