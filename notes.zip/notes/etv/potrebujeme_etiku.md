# Potrebujeme etiku?

Aby sme vedeli, či etiku potrebujeme (nie len ako predmet na škole), potrebujeme vedieť, čo vlastne etika je a za akou *"zámnienkou"* vôbec existuje. Etika Je *vedná disciplína*, zaoberajúca sa ľudským správaním, morálkou a správnym konaním. Vedeli by sme teda odpovedať na dve rôzne otázky: *"Potrebujeme zásady morálneho správania?"* a *"Potrebujeme vednú disciplínu etiky?"*. Obe otázky zodpoviem.

## Potrebujeme zásady morálneho správania?

Každý systém má svoje pravidlá, ktoré musí dodržiavať, aby správne fungoval. Nakoľko môžeme tvrdiť, že ako jedinec sme úplne samostatný, pravda je iná. Jeden človek by toho sám vôbec nezvládol toľko, ako celé ľudstvo dokopy. Keby neexistovali pravidlá, kotré hovoria ako správne spolupracovať a spolunažívať s inými ľuďmi, bolo by ťažké nadviazať na prácu iných a dotiahnuť to až tak ďaleko, ako to ľudstvo dotiahlo. Ľudia tvoria systém a etika sú jeho praidlá.

## Potrebujeme vedu zaoberajúcu sa týmito zásadami?

Každá vedná disciplína sa v prvom rade zakladá na zvedavosti človeka. Etika sa snaží poznať niečo hlbšie o našom správaní, našich hodnotách; chce zistiť, prečo a ako vznikli pravidlá morálneho správania, ako to ovplyvňuje nás a veci naokolo. Etika sa takisto snaží kvantifikovať mnohé sociálne javy na objektívnej úrovni. Toto je podľa mňa chyba, kotrú robia mnohé sociálne vedy. Nie všetko sa dá presne popísať - už iba preto, lebo každý človek je iný, no aj preto, lebo príroda nerozmýšľa rovnako ako my a niektoré veci, ktoré sa v nej dejú, neviemie stopercentne opísať.

Čiže podľa mňa je etika ďalšia zbytočná socíalna veda - hodnotenie: $^3/_{10}$
