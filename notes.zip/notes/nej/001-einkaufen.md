# Einkaufen

Ist die Tätigkeit mit dem Ziel etwas zi kaufen oder z uverkaufen. handeln mit

## Warum Handeln Wir?

 - um etwas zu verdienen
 - um reicher zu wedren
 - um etwas Neues zu kaufen
 -	um Spaß zu haben
 - um uns zu amüsieren

schoppen gehen, Klamoten anprobieren

## Wo ist es möglich zu handeln?

 - in einem **Laden** - bäckerei, bücherei, konditorei, fleisherei, metzgerei
 - in einem **Tante-Emma-Laden** - ein Geschäft auf den Lande, wo man alles unter einem Dach kaufen kann
 - auf Einem **Markt** - man handelt undet dem freien Himmel
   - Trödelmarkt - Antiquitäten
   - Flohmarkt - blší trh
 - in einem **Supermarkt** kann man alles under einem Dach kaufen
 - in den **Einkaufszentren** kann man nich nur einkaufen, sondern auch *in Imbiss etwas essen*, ins Café oder Kino gehen, die *Kinder können betreut werden*, währen ihre Eltern einkaufen.

> e Waren - tovar

### Bäckerei

 - s Gebäck
   - Brot
   - Brötchen
   - Kipferln
   - 

### Konditorei

 - cukráreň

### Fleischerei

 - Fleisch
 - Wurst
 - Würstchen

### Metzgerei

 - total frisches fleisch
 - tiere werden dort getötet

### Tante-Emma-Laden

 - die Kunden sind bedient

> Breit - široký

### Markt

> gebraucht - jemand hat shon die Ware gebraucht

### Supermarkt

 - selbstbedienung

## Wie und wo ist es möglich zu zahlen?

 - An der Kasse
 - Mit einer Kreditkarte
 - Mit dem Bargeld (e Münzen, e Banknoten, bewahren wir in der Geldtasche oder im Geldbeutel)
