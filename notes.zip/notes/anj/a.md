1:F she was a student
2:T
3:F there was a party for all the actors and the film crew
4:F the interpreter couln't come
5:T

# QUIZ

1 B    no, C
2 C    yees
3 A/C? :(
4 B    yeeeeeeeeeeeeeeeeeeeesaaaaaaaaaaaaaaa
5 C?   wtf just 3 years

**!!UWAGA!!**

 - public schools - actually private
 - state schools - public

WTF

UK:

16 - GCSE
18-19 - A-level test

US:

SAT - scholastic achievement test
