# Metódy skúmania tepelných vlastností látok

 - termodynamická metóda
   - nepoznáme vnútornú štruktúru látok
   - stavové veličiny - $p$ - tlak, $V$ - objem, $E$ - energia
 - štatistická metóda
   - vnútornú štruktúru látok poznáme
   - opsuje konkrétne molekuly / atómy látky
   - využíva štatistickú matematiku

## Štatistická metóda

základom štatistickej fyziky a molekulovej fyziky je *kinetická teória látok*.

### Kinetická teória látok

základom kinetickej teórie látok sú výsledky experimentov.

1. každá látka je zložená z častíc - atómov, molekúl
2. častice sa neustálne a neusporiadane pohybujú
   - difúzia - dej **samovoľného** prenikania molekúl jednej látky medzi molekuly druhej látky rovnakého skupenstva
     - napríklad šírenie pachov
   - osmóza - samovoľné prenikanie látok cez membránu
     - napríklad keď uhorka púšťa šťavu keď je posolená
   - Brownov pohyb
3. medzi časticami vždy existujú vzájmné príťažlivé a odpudivé sily

### Tlak plynu

> Tlak plynu je spôsobený zrážkou častice so stenou nádoby.

Ak by nebol v plyne žiaden pohyb, nenastávali by zrážky a tlak by nebol.


> jeden atóm má približne $10^{-10}m$

\pagebreak

### Rovnovážna poloha

![rovnováha nastáva v bode F = 0](d35a.png)

Pre dve molekuly navzájom platí príťažlivá aj odpudivá sila. Odpudivá sila má vyšší exponent a teda pre krátke vzdialenosti sa častice odpudzujú. Pre väčšie vzdialenosti sa častice priťahujú. Existuje istá rovnovážna poloha $r_0$, pki ktorej na častice pôsobí navzájom nulová sila.

vzdialenosť | sila
---         | ---
$<r_0$      | odpudivá
$>r_0$      | príťažlivá

Príťažlivé sily majú elektrostatický charakter a odpudivé sily majú kvantový charakter - na základ Pauliho vylučovacieho princúpu.

$F_0, F_p$ - vazbové sily

$r_0$ - rovnovážna poloha

väzbová energia - energia v rovnovážnej polohe.

$E_v = -\int_{r_0}^{\infty} F(x) dx$

\pagebreak

## Rovnováha sústavy

Teleso môže byť v rôznych stavoch a fázach - skupenstvo, kryštalická štruktúra,
či iné vlastnosti ako teplota. Skupina telies, ktorých stav skúmame sa bude
volať **termodynamická sústava**.

> Systém po istom čase prejde samovoľne do *rovnovážneho stavu*.

### Rovnovážny dej

Rovnovážny dej je taký, kde sústavá precházda viacerými rovnovážnymi stavmi.

### Stavové veličiny

Veličiny, ktoré charakterizujú stav sústavy:

veličina              | skr.
----------------------|-----
temodynamická teplota | T
Tlak                  | p
Objem                 | V
Energia               | E

### Typy systémov

systém    | výmena energie  s okolím | výmena hmoty s okolím
----------|--------------------------|-----------------------
Otvorený  | áno                      | áno
Uzavretý  | áno                      | nie
Izolovaný | nie                      | nie

## Teplota

Skalárna stavová veličina, ktorá charakterizuje termodynamický stav telesa.

Termodynamická teplota `T [K]`

$0^oC = 273.15K$

0K = **absolútna nula** - nikdy ju nedosiahneme

### Druhy teplomerov

 - dilatačné
   - využívajú vzťah teploty k veľkosti

### Tepelné stupnice

#### Celziova

 0 - rovnovážny stav voda/ľad
 100 - voda, vodná para

#### Farenhajtova

 0 - voda ľad a soľ
 32 - voda ľad

#### Kelvinova

 273.16 - voda, ľad a para

$t(^oC) = (t[^oF]-32) \frac{5}{9}$
