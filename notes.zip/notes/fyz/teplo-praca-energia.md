# Teplo, práca a vnútorná energia

**teplo** - prechádza z jedného telesa do druhého v dôsledku pôsobenia rozdielu teplôt
**teplota** - prechádza z jedného telesa do duhého na základe sily

## Nultý zákon termodynamiky

Ak sú telesá A a B v tepelnej rovnováhe s telesom C, tak sú A a B v tepelnej rovnovahe navzájom. V tepelenj rovnováhe majú telesá rovnakú teplotu.


# Kalorimetrická rovnica

$\delta{}t_1c_1m_1 = \delta{}t_2c_2m_2$


!()[369f.png]

# Termodynamický Zákon

Zmena vnútornej energie môže nastať:

 - konaním práce
 - prenosom tepla

`Q = 0` - **adiabatický jav**

--- 

v kalorimetri s $c=63 J/K$ je olej s $m=250g; t=12^oC$. Do oleja ponoríme medený valček s $m=500g$ a $t=100^oC$. Výsledná teplota je $33^oC$.
