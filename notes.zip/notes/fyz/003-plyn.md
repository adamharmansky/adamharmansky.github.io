Ideálny plyn, čo o ňom predpokladáme: 

1, Rozmery molekúl ideálneho plynu sú zanedbateľne malé v porovnaní so strednou vzájomnou vzdialenosťou molekúl 

2, Molekuly ideálneho plynu nepôsobia na seba navzájom príťažlivými silami 

3, vzájomné zrážky dvoch molekúl ako aj zrážky molekúl plynu so stenami nádoby sú dokonale pružné 

Celková kinetická energia sa zachováva, kinetická energia pred zrážkou sa rovná kinetickej energie po zrážke 

4, Čas trvania zrážky dvoch molekúl ideálneho plynu je veľmi krátky v porovnaní so strednou dobou voľného pohybu molekúl, keď sa molekuly pohybujú rovnomerným priamočiarym pohybom 
