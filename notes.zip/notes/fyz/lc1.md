---
geometry: margin=1in
---

\title{LABORATÓRNE CVIČENIE Z FYZIKY}
\maketitle{}

\underline{\textbf{TÉMA}}: **URČENIE MERNEJ TEPELNEJ KAPACITY PEVNEJ LÁTKY ZMIEŠAVACÍM KALORIMETROM**

\underline{\textbf{DÁTUM}}: \today \hspace{2cm} \underline{\textbf{MENO}}: Adam Harmanský

\underline{\textbf{POMÔCKY}}: zmiešavací kalorimeter s príslušenstvom, laboratórne váhy, sada závaží, ohrievač s vodným kúpeľom, kovový predmet

\underline{\textbf{FYZIKÁLNY PRINCÍP}}:

Keď medzi teplejším telesom a chladnejšou kvapalinou prebieha v kalorimetri tepelná výmena platí kalorimetrická rovnica v tvare: 

\begin{center}
$Q_{od} = Q_{pr}$

$Q_1 = Q_2 + Q_3$
\end{center}

kde:

 - $Q_1$ je teplo odovzdané teplejším telesom (horúcim kovom).
 - $Q_2$ je teplo prijaté chladnejšou kvapalinou.
 - $Q_3$ je teplo prijaté kalorimetrom.

Ak označíme teploty $t_1$ - začiatočná teplota teplejšieho telesa, $t_2$ - začiatočná teplota kvapaliny a $t$ - výsledná teplota sústavy po dosiahnutí rovnovážneho stavu,

\begin{center}
$m_1c_1(t_1-t) = m_2c_2(t-t_2)+m_kc_k(t-t_2)$
\end{center}

možno určiť mernú tepelnú kapacitu $c_1$ daného kovu nasledovne:

\begin{center}
$c_1 = \frac{m_2c_2(t-t_2)+m_kc_k(t-t_2)}{m_1(t_1-t)}$
\end{center}

\pagebreak

\textbf{\underline{POSTUP}}:

1. Pripravte laboratórne váhy na váženie.
1. Odmerajte hmotnosť $m_1$ kovového predmetu. 
1. Vložte kovový predmet do vodného kúpeľa. Zapnite ohrievač. 
1. Odmerajte hmotnosť $m_k$ vnútornej nádoby spolu s vrchnákom kalorimetra. Nalejte do kalorimetra vodu (približne do polovičky nádoby). Odmerajte hmotnosť $m_k + m_2$ vnútornej nádoby kalorimetra s príslušenstvom a vodou a vypočítajte $m_2$.
1. Teplomerom odmerajte tesne pred vložením telesa teplotu $t_2$ vody v kalorimetri,
1. $c_2$ nájdite v tabuľkách podľa teploty vody.
1. Teplota $t_1$ je teplota vodného kúpeľa - $100 ^oC$.
1. Preneste kovový predmet do kalorimetra. Kalorimeter uzavrite a nechajte prebehnúť tepelnú výmenu (prenesenie predmetu do kalorimetra musí byť veľmi rýchle). 
1. Teplomerom odmerajte teplotu $t$ sústavy po dosiahnutí rovnovážneho stavu.
1. Z nameraných údajov vypočítajte mernú tepelnú kapacitu daného kovu. Výsledok určte formou intervalu a relatívnej chyby merania.

$\frac{m_1}{kg}$ | $\frac{m_k}{kg}$ | $\frac{m_k + m_2}{kg}$ | $\frac{m_2}{kg}$ | $\frac{c_k}{J\cdot{}kg^{-1}K^{-1}}$ | $\frac{c_2}{J\cdot{}kg^{-1}K^{-1}}$ | $\frac{t_2}{^oC}$ | $\frac{t_1}{^oC}$ | $\frac{t}{^oC}$ | $\frac{c_1}{J\cdot{}kg^{-1}K^{-1}}$ | $\frac{\Delta{}c_1}{J\cdot{}kg^{-1}K^{-1}}$
-----------|-----------|-----------------|-----------|------------------------------|------------------------------|------------|------------|----------|------------------------------|-------------------------------------
$0.0414$   | $0.0824$  | $0.2613$        | $0.1789$  | $896$                        | $4180$                       | $22$       | $100$      | $25$     | $793,84$                     | $128.65$
$0.0416$   | $0.0833$  | $0.2525$        | $0.1692$  | $896$                        | $4180$                       | $21$       | $100$      | $25$     | $1002.43$                    | $79.94$
$0.0414$   | $0.0830$  | $0.2452$        | $0.1625$  | $896$                        | $4180$                       | $21$       | $100$      | $25$     | $971.19$                     | $48.7$
|           |           |                 |           |                              |                              |            |            |          | $922.49$                     | $85.67$

\textbf{\underline{ZÁVER}}:

S neveľkou presnosťou sme odmerali mernú tepelnú kapacitu hliníkového valčeka, ktorá nám vyšla $c_1 = (922.49 \pm 85.67)J\cdot{}kg^{-1}K^{-1}$ s relatívnou chybou $9.2\%$. Od tabuľkovej hodnoty $867 J\cdot{}kg^{-1}K^{-1}$ sa líši približne o $55J\cdot{}kg^{-1}K^{-1}$ čo je $6.3\%$. Nepresnosti nastali pri prenášaní valčeka do nádoby, nedostatočnom zahriatí valčeka, úniku tepla v kalorimetri a nepresnej teplote vody.
